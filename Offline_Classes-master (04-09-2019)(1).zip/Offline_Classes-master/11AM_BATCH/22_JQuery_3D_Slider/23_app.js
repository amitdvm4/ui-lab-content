$(".slider").jasCarousel({
    margin: 20,
    auto:true,
    speed: 800,
    delay: 1000,
    slideFrontFace: false,
    moveOnSlideClick: false,
    prevText:'Prev',
    nextText:'Next'
});