

 function libFn(){
	$.fn.setNitText=function(){
	return $(this).text('naresh it');
     }
 }

libFn();

