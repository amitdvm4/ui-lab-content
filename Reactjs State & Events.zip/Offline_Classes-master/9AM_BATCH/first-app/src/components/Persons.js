import React , {Component} from 'react';
import Person from "./Person";

class Persons extends Component{

    constructor(props){
        super(props);
        this.state = {
            persons : [
                {
                    name : 'Laura',
                    age : 40,
                    designation : 'Manager'
                },
                {
                    name : 'Wilson',
                    age : 45,
                    designation : 'Sr. Manager'
                },
                {
                    name : 'Rajan',
                    age : 25,
                    designation : 'Software Engineer'
                },
                {
                    name : 'Mahesh',
                    age : 35,
                    designation : 'Team Lead'
                }
            ]
        };
    }

    render() {
        let personsData = this.state.persons.map((person) => {
            return <Person person={person}/>
        });

        return(
            <div>
                {personsData}
            </div>
        );
    }
}

export  default Persons;