import React , {Component} from 'react';

class Person extends Component{
    constructor(props){
        super(props);
    }

    render() {
        let {person} = this.props;
        return(
            <div className='card m-3' >
                <div className="card-body bg-success text-white">
                    <p className="lead">{person.name}</p>
                    <p className="lead">{person.age}</p>
                    <p className="lead">{person.designation}</p>
                </div>
            </div>
        );
    }
}

export default  Person;