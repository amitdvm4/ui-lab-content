import React from 'react';
import './App.css';
import ChangeRangeSelect from "./components/examples/ChangeRangeSelect";


function App() {
  return (
    <div className="App">
      <div className="container mt-4">
          <div className="row">
              <div className="col-md-6">
                  <div className="card">
                      <div className="card-body bg-primary">
                         <ChangeRangeSelect/>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
}

export default App;
