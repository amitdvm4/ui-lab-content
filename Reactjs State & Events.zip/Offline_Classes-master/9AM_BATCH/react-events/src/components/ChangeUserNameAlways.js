import React , {Component} from 'react';

class ChangeUserNameAlways extends Component{

    constructor(props){
        super(props);
        this.state = {
            username : '',
            password: ''
        };
    }

    // changeInputField
    changeInputField = (event) => {
        this.setState({
            [event.target.name] : event.target.value
        });
    };

    render() {
        return(
            <div>
                <form>
                    <div className="form-group">
                        <input
                            type='text'
                            className='form-control'
                            placeholder='User Name'
                            name = 'username'
                            value={this.state.username}
                            onChange={this.changeInputField}/>
                        <p className="lead font-weight-bold">{this.state.username}</p>
                    </div>
                    <div className="form-group">
                        <input
                            type='text'
                            className='form-control'
                            placeholder='Password'
                            name = 'password'
                            value={this.state.password}
                            onChange={this.changeInputField}/>
                        <p className="lead font-weight-bold">{this.state.password}</p>
                    </div>
                </form>
            </div>
        );
    }
}
export  default ChangeUserNameAlways;