import React , {Component} from 'react';

class ChangeSelectBox extends Component{

    constructor(props){
        super(props);
        this.state = {
            selectedOption : ''
        }
    }

    // Event Handler
    changeInputFiled = (event) => {
        this.setState({
            [event.target.name] : event.target.value
        });
    };

    render() {
        return(
            <div>
                <form>
                    <div className="row">
                        <div className="col">
                            <div className="form-group">
                                <select
                                    className='form-control'
                                    name='selectedOption'
                                    value={this.state.selectedOption}
                                    onChange={this.changeInputFiled}>
                                    <option value="">Select a Technology</option>
                                    <option value="HTML">HTML</option>
                                    <option value="CSS">CSS</option>
                                    <option value="JavaScript">JavaScript</option>
                                    <option value="React JS">React JS</option>
                                    <option value="Node JS">Node JS</option>
                                </select>
                            </div>
                        </div>
                        <div className="col">
                            <h3 className="font-weight-bold text-danger">{this.state.selectedOption}</h3>
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}
export  default ChangeSelectBox;