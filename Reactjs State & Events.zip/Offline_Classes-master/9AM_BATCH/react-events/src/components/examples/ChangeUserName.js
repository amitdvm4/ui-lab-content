import React , {Component} from 'react';

class ChangeUserName extends Component{

    constructor(props){
        super(props);
        this.state = {
            username : '',
            password: ''
        };
    }

    // Change User Name
    changeUserName = (event) => {
        this.setState({
            username : event.target.value
        });
    };

    // Change Password
    changePassword = (event) => {
        this.setState({
            password : event.target.value
        });
    };


    render() {
        return(
            <div>
                <form>
                    <div className="form-group">
                        <input
                            type='text'
                            className='form-control'
                            placeholder='User Name'
                            value={this.state.username}
                            onChange={this.changeUserName}/>
                        <p className="lead font-weight-bold">{this.state.username}</p>
                    </div>
                    <div className="form-group">
                        <input
                            type='text'
                            className='form-control'
                            placeholder='Password'
                            value={this.state.password}
                            onChange={this.changePassword}/>
                        <p className="lead font-weight-bold">{this.state.password}</p>
                    </div>
                </form>
            </div>
        );
    }
}
export  default ChangeUserName;