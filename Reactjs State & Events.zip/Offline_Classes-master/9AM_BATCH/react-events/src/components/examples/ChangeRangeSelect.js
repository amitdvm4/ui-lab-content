import React , {Component} from 'react';

class ChangeRangeSelect extends Component{

    constructor(props){
        super(props);
        this.state = {
            selectedValue : ''
        };
    }

    // Event Handler
    changeInputFiled = (event) => {
        this.setState({
            [event.target.name] : event.target.value
        });
    };

    render() {
        return(
            <div>
                <form>
                    <div className="row">
                        <div className="col">
                            <div className="form-group">
                                <input
                                    type='range'
                                    className='custom-range'
                                    min='5000'
                                    max='5000000'
                                    name='selectedValue'
                                    value={this.state.selectedValue}
                                    onChange={this.changeInputFiled}/>
                            </div>
                        </div>
                        <div className="col">
                            <h3 className="font-weight-normal text-white"> &#8377; {new Intl.NumberFormat('en-IN', { maximumSignificantDigits: 3 }).format(this.state.selectedValue)}</h3>
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}
export  default ChangeRangeSelect;