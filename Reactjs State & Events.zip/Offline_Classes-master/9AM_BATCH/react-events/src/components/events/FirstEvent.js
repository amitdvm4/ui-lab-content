import React from 'react';

let FirstEvent = () => {

    let clickHandler = () => {
        console.log('Button is Clicked');
    };

    return(
        <div>
            <h1>First Event</h1>
            <button className='btn btn-primary' onClick={clickHandler}>Click Me</button>
        </div>
    );
};

export default FirstEvent;