# HTML -> 10 days
# CSS -> 7 days
# JavaScript ->  10days
# BS -> 7 days
# JQuery -> 7 days
# Node JS -> 7 days
# React JS -> 7 days
