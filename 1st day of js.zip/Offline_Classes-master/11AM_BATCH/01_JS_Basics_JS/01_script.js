// Log Message
console.log('Iam a Log Message');

// Info Message
console.info('Iam an information Message');

// warning Message
console.warn('Iam a Warning Message');

// Error Message
console.error('Iam an Error Message');
