// String
let empName = 'John';
console.log(`value : ${empName} Type : ${typeof empName}`);

// Number
let empAge = 40;
console.log(`value : ${empAge} Type : ${typeof empAge}`);

// boolean
let isManager = true;
console.log(`value : ${isManager} Type : ${typeof isManager}`);

// null
let isMarried = null;
console.log(`value : ${isMarried} Type : ${typeof isMarried}`);

// undefined
let companyName;
console.log(`value : ${companyName} Type : ${typeof companyName}`);

// Variable Re-assignment
let a ;
console.log(`value : ${a} Type : ${typeof a}`);

a = 10;
console.log(`value : ${a} Type : ${typeof a}`);

a = 'Rajan';
console.log(`value : ${a} Type : ${typeof a}`);

a  = true;
console.log(`value : ${a} Type : ${typeof a}`);

a = null;
console.log(`value : ${a} Type : ${typeof a}`);
